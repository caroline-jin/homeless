import geopy
import pandas as pd
from geopy.geocoders import Nominatim, GoogleV3
import numpy as np
import folium

def main():
    filename = '2017.csv'
    data = pd.read_csv(filename, index_col=None, header=0, sep=",")
    m = folium.Map(location=[34.0522, -118.2437], tiles='Stamen Toner',
                   zoom_start=10, control_scale=True)
    outfp = "base_map.html"
    m.save(outfp)

    #def get_latitude(x):
    #    return x.latitude

    #def get_longitude(x):
    #  return x.longitude

    #geolocator = GoogleV3
    #geolocate_column = data['Address'].apply(geolocator.geocode)
    #data['latitude'] = geolocate_column.apply(get_latitude)
    #data['longitude'] = geolocate_column.apply(get_longitude)
    #data.to_csv('2017.csv')

if __name__ == '__main__':
     main()
